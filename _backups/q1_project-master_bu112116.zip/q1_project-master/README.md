## Q1 Project : Real-Time Temp/Barometer/Altitude Station
***
_Base functionality:_ .  
Pull sensor readings from AVR mCPU and push to webpage.   
Contrast actual measurements agains a web based service API (Underground Weather) .  
Display raw sensor readings and additional API values on Diag page . 

_Add-on:_ . 
If possible:     
Suggest daily activities based on weather . 
Display historical values for current date (as/if available) . 

_Hardware Used:_ . 
_API's Used:_ . 

